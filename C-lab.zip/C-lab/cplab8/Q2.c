#include<stdio.h>
int main()
{
int number,i,sum = 0;
printf("enter  a positive integer:");
scanf("%d",number):#include <stdio.h>

int main() {
    int number, i, sum = 0;

    // Prompt user for input
    printf("Enter a number to check if it is a perfect number: ");
    scanf("%d", &number);

    // Check for valid input (perfect numbers are positive integers)
    if (number <= 0) {
        printf("Please enter a positive integer.\n");
        return 1; // Indicate an error
    }

    // Loop to find all proper divisors and calculate their sum
    // Proper divisors are divisors excluding the number itself
    for (i = 1; i < number; i++) {
        if (number % i == 0) {
            sum = sum + i;
        }
    }

    // Check if the sum of proper divisors equals the number
    if (sum == number) {
        printf("%d is a Perfect Number.\n", number);
    } else {
        printf("%d is not a Perfect Number.\n", number);
    }

    return 0; // Indicate successful program termination
}

