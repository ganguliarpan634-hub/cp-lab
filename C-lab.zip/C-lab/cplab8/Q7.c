#include <stdio.h>

// Function to calculate factorial of a digit
int factorial(int n) {
    int fact = 1;
    for(int i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int num, temp, sum = 0, digit;

    printf("Enter a number: ");
    scanf("%d", &num);

    temp = num;

    while (temp > 0) {
        digit = temp % 10;            // extract last digit
        sum += factorial(digit);      // add factorial of digit
        temp /= 10;                   // remove last digit
    }
#include <stdio.h>

// Function to calculate factorial of a digit
int factorial(int n) {
    int fact = 1;
    for(int i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int num, temp, sum = 0, digit;

    printf("Enter a number: ");
    scanf("%d", &num);

    temp = num;

    while (temp > 0) {
        digit = temp % 10;            // extract last digit
        sum += factorial(digit);      // add factorial of digit
        temp /= 10;                   // remove last digit
    }

    if (sum == num)
        printf("%d is a Strong number.\n", num);
    else
        printf("%d is NOT a Strong number.\n", num);


#include <stdio.h>
int factorial(int n) {
    int fact = 1;
    for(int i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int num, temp, sum = 0, digit;

    printf("Enter a number: ");
    scanf("%d", &num);

    temp = num;

    while (temp > 0) {
        digit = temp % 10;
        sum += factorial(digit);
        temp /= 10;
    }

    if (sum == num)
        printf("%d is a Strong number.\n", num);
    else
        printf("%d is NOT a Strong number.\n", num);

    return 0;
}

    if (sum == num)
        printf("%d is a Strong number.\n", num);
    else
        printf("%d is NOT a Strong number.\n", num);

    return 0;
}
