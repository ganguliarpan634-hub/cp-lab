#include <stdio.h>

int main() {
    int n;
    int l1 = 1, l2 = 3;
    int nextLucas;

    printf("Enter the number of Lucas numbers to generate: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive number.\n");
    } else if (n == 1) {
        printf("Lucas Sequence: %d\n", l1);
    } else if (n == 2) {
        printf("Lucas Sequence: %d, %d\n", l1, l2);
    } else {
        printf("Lucas Sequence: %d, %d", l1, l2);
        for (int i = 3; i <= n; ++i) {
            nextLucas = l1 + l2;
            printf(", %d", nextLucas);
            l1 = l2;
            l2 = nextLucas;
        }
        printf("\n");
    }

    return 0;
}
