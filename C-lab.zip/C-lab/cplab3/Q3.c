#include<stdio.h>
int main()
{
float radius,area;
printf("enter the radius:");
scanf("%f",&radius);
area = 22/7*radius*radius;
printf("the value of area is %f",area);
return 0;
}

