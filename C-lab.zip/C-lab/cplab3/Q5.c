#include<stdio.h>
int main()
{
int number1,number2,temp;
printf("enter number1:",number1);
scanf("%d",&number1);
printf("enter number2:",number2);
scanf("%d",&number2);
printf("before swapping number1 is %d,number2 is %d");
temp=number1;
number1=number2;
number2=temp;
printf("after swapping number1 is %d,number2 is %d");
return 0;
}
