#include<stdio.h>
int main()
{
int base,height,area;
printf("enter the base:");
scanf("%d",&base);
printf("enter the height");
scanf("%d",&height);
area = 1/2*base*height;
printf("the value of are is %d",area);
return 0;
}
