#include<stdio.h>
int main()
{
float celcius,farenheit,temperature;
printf("enter temperature in celcius:",celcius);
scanf("&f",&celcius);
farenheit = celcius*(9/5)+32;
printf("the value of celcius is %f = the value of farenheit is %f");
return 0;
}

