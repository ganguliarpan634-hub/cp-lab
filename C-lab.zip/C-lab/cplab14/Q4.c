#include <stdio.h>
struct Student {
    int rollNo;
    char name[50];
    char gender;
    float marks;
};
int main() {
    struct Student s1;
    printf("Enter student roll number: ");
    scanf("%d", &s1.rollNo);

    printf("Enter student name: ");
    scanf("%s", s1.name);

    printf("Enter student gender (M/F): ");
    scanf(" %c", &s1.gender);

    printf("Enter student marks: ");
    scanf("%f", &s1.marks);
    printf("\n--- Student Information ---\n");
    printf("Roll Number : %d\n", s1.rollNo);
    printf("Name        : %s\n", s1.name);
    printf("Gender      : %c\n", s1.gender);
    printf("Marks       : %.2f\n", s1.marks);

    return 0;
}
