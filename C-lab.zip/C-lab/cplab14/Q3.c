#include <stdio.h>

#define NUM_SUBJECTS 5
#define MAX_STUDENTS 100
#define PASS_MARK 40
struct Student {
    int roll_no;
    char name[50];
    char gender[10];
    int marks[NUM_SUBJECTS];
    int total_marks;
};

int main() {
    struct Student students[MAX_STUDENTS];
    int n;
    printf("Enter the number of students: ");
    scanf("%d", &n);

    if (n > MAX_STUDENTS || n <= 0) {
        printf("Invalid number of students. Please enter a value between 1 and %d.\n", MAX_STUDENTS);
        return 1;
    }
    for (int i = 0; i < n; i++) {
        printf("\n--- Enter details for student %d ---\n", i + 1);

        printf("Roll Number: ");
        scanf("%d", &students[i].roll_no);

        printf("Name: ");
        scanf("%s", students[i].name);

        printf("Gender: ");
        scanf("%s", students[i].gender);

        students[i].total_marks = 0;
        printf("Enter marks for %d subjects:\n", NUM_SUBJECTS);
        for (int j = 0; j < NUM_SUBJECTS; j++) {
            printf("Subject %d: ", j + 1);
            scanf("%d", &students[i].marks[j]);
            students[i].total_marks += students[i].marks[j];
        }
    }
    printf("\n\n--- All Student Data ---\n");
    printf("Roll\tName\t\tGender\t\tTotal Marks\n");
    printf("--------------------------------------------------\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t%s\t\t%s\t\t%d\n", students[i].roll_no, students[i].name, students[i].gender, students[i].total_marks);
    }

    int subject_to_check;
    printf("\nEnter the subject number (1-%d) to check for failures: ", NUM_SUBJECTS);
    scanf("%d", &subject_to_check);

    if (subject_to_check >= 1 && subject_to_check <= NUM_SUBJECTS) {
        printf("\n--- Students who failed in Subject %d ---\n", subject_to_check);
        int failed_count = 0;
        for (int i = 0; i < n; i++) {
            if (students[i].marks[subject_to_check - 1] < PASS_MARK) {
                printf("%d\t%s\n", students[i].roll_no, students[i].name);
                failed_count++;
            }
        }
        if (failed_count == 0) {
            printf("No students failed in Subject %d.\n", subject_to_check);
        }
    } else {
        printf("Invalid subject number.\n");
    }

    return 0;
}
