#include <stdio.h>
#include <stdlib.h>
struct Employee {
    char name[50];
    char gender;
    char designation[50];
    char department[50];
    float basicPay;
    float grossPay;
};

int main() {
    struct Employee *emp;
    int n, i;
    printf("Enter the number of employees: ");
    scanf("%d", &n);
    emp = (struct Employee *)malloc(n * sizeof(struct Employee));

    if (emp == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    for (i = 0; i < n; i++) {
        printf("\nEnter details of employee %d:\n", i + 1);

        printf("Name: ");
        scanf("%s", emp[i].name);

        printf("Gender (M/F): ");
        scanf(" %c", &emp[i].gender);

        printf("Designation: ");
        scanf("%s", emp[i].designation);

        printf("Department: ");
        scanf("%s", emp[i].department);

        printf("Basic Pay: ");
        scanf("%f", &emp[i].basicPay);
        float HR = 0.25 * emp[i].basicPay;
        float DA = 0.75 * emp[i].basicPay;
        emp[i].grossPay = emp[i].basicPay + HR + DA;
    }
    printf("\n--- Employee Details and Gross Pay ---\n");
    for (i = 0; i < n; i++) {
        printf("\nEmployee %d:\n", i + 1);
        printf("Name        : %s\n", emp[i].name);
        printf("Gender      : %c\n", emp[i].gender);
        printf("Designation : %s\n", emp[i].designation);
        printf("Department  : %s\n", emp[i].department);
        printf("Basic Pay   : %.2f\n", emp[i].basicPay);
        printf("Gross Pay   : %.2f\n", emp[i].grossPay);
    }

    free(emp);

    return 0;
}

