#include <stdio.h>
struct Time {
    int hr;
    int min;
    int sec;
};
struct Time addTime(struct Time t1, struct Time t2) {
    struct Time sum;

    sum.sec = t1.sec + t2.sec;
    sum.min = t1.min + t2.min + (sum.sec / 60);
    sum.sec = sum.sec % 60;

    sum.hr = t1.hr + t2.hr + (sum.min / 60);
    sum.min = sum.min % 60;

    return sum;
}

int main() {
    struct Time t1, t2, result;
    printf("Enter first time:\n");
    printf("Hours: ");
    scanf("%d", &t1.hr);
    printf("Minutes: ");
#include <stdio.h>

int main() {
    char str[100];
    int i, length = 0;

    printf("Enter a string: ");
    gets(str);  // or use fgets(str, sizeof(str), stdin);

    // Count characters until null terminator '\0' is reached
    for (i = 0; str[i] != '\0'; i++) {
        length++;
    }

    printf("Length of the string: %d\n", length);

    return 0;
}
    scanf("%d", &t1.min);
    printf("Seconds: ");
    scanf("%d", &t1.sec);
    printf("\nEnter second time:\n");
    printf("Hours: ");
    scanf("%d", &t2.hr);
    printf("Minutes: ");
    scanf("%d", &t2.min);
    printf("Seconds: ");
    scanf("%d", &t2.sec);
    result = addTime(t1, t2);
    printf("\n--- Sum of Times ---\n");
    printf("%02d:%02d:%02d\n", result.hr, result.min, result.sec);

    return 0;
}

