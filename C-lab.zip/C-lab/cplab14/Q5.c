#include <stdio.h>
struct Distance {
    int km;
    int meter;
};

int main() {
    struct Distance d1, d2, sum;
    printf("Enter first distance:\n");
    printf("Kilometers: ");
    scanf("%d", &d1.km);
    printf("Meters: ");
    scanf("%d", &d1.meter);
    printf("\nEnter second distance:\n");
    printf("Kilometers: ");
    scanf("%d", &d2.km);
    printf("Meters: ");
    scanf("%d", &d2.meter);
    sum.km = d1.km + d2.km;
    sum.meter = d1.meter + d2.meter;
    if (sum.meter >= 1000) {
        sum.km += sum.meter / 1000;
        sum.meter = sum.meter % 1000;
    }
    printf("\n--- Sum of Distances ---\n");
    printf("%d kilometers and %d meters\n", sum.km, sum.meter);

    return 0;
}
