#include<stdio.h>
int main()
{printf("welcome to hello world");
return 0;
}
