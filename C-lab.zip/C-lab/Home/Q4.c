#include <stdio.h>
void main()
{
float celcius,fahrenheit;
printf("enter the value in celcius:");
scanf("%f",&celcius);
fahrenheit = celcius*(9/5)+32;
printf("%.2ffahrenheit=%.2fcelcius",celcius,fahrenheit);
}
