#include<stdio.h>
int main()
{
int num,remainder,reversenumber;
printf("enter the the number:");
scanf("%d",num);
while (num!=0){
remainder = num/10;
reversenumber = reversenumber *10 + num;
num/=10;
}
printf("%d reversenumber:",reversenumber):
return 0;
}
