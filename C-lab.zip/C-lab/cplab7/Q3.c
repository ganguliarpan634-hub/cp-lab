'#include<stdio.h>
int main(){
int n,i,start;
int main()
{ int i,start;
printf("enter starting value:");
scanf("%d",start);
for (i = start;i>=1;i--){
printf("%d",i);
}

return 0;
}
