#include <stdio.h>
int main()
{int i;
printf("Even numbers up to 50:\n");
for( i=2;i<=50;i=i+2)
printf("%d",i);
}
return 0;
}

