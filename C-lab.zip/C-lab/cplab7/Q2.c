#include<stdio.h>
int main()
{
int num,i;
printf("enter any integer:");
scanf("%d",&num);
if (num>0)[
printf("list of natural number from 1 to %d are\n",num);
for (i=1;i<=num;i++);{
printf("%d",i);
}
else{
 ("enter a valid number"\n");
}
return 0;
}
