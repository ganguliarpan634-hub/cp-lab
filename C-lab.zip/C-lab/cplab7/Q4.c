#include<stdio.h>
int main(){
int i,num,sum=0;
float avg;
for (i=1;i<11;i++){
printf("number is %d =",i);
scanf("%d",&num);
sum = sum + num; 
avg = sum + num;
}
printf("sum of the total number is %d",sum);
printf("the avg of total number is %f",avg);
return 0;
}
