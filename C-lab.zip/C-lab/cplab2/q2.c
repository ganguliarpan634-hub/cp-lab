#include<stdio.h>
void main()
{
int a,b,c;
printf("enter the value of a:");
scanf("%d", &a);
printf("the value of b:");
scanf("%d", &b);
c = a+b;
printf("the sum of %d and %d is %d");
}

