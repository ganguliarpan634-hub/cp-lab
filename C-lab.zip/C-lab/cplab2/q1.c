#include<stdio.h>
void main()
{
int a,b,sum ;
printf("enter the value of a:");
scanf("%d",&a);
printf("enter the value of b: ");
scanf("%d",&b);
sum=a+b;
printf("the sum of %d and %d is %d");
}


