#include<stdio.h>
void swap (int a,int b){
{
int c;
c=a;
a=b;
b=c;
}
int main()
{
int x,y ;
printf("enter two numbers:");
scanf("%d,%d",&x,&y);
printf("before swapping the value of %d is %d");
swap(&num1,&num2);
prontf("after swapping the value of %d is %d");
return 0;
}

