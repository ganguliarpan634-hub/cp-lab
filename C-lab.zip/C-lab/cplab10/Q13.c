#include <stdio.h>
int product(int a, int b) {
    if (b == 0)
        return 0;
    else if (b > 0)
        return a + product(a, b - 1);
    else
        return -product(a, -b);
}

int main() {
    int num1, num2, result;


    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);
    result = product(num1, num2);
    printf("Product of %d and %d is: %d\n", num1, num2, result);

    return 0;
}
