#include <stdio.h>
void fibonacci(int n, int a, int b) {
    int i, next;
    printf("Fibonacci Series: %d %d ", a, b);

    for(i = 3; i <= n; i++) {
        next = a + b;
        printf("%d ", next);
        a = b;
        b = next;
    }
    printf("\n");
}

int main() {
    int n, a, b;

    printf("Enter the number of terms: ");
    scanf("%d", &n);

    printf("Enter first two numbers: ");
    scanf("%d %d", &a, &b);

    fibonacci(n, a, b);

    return 0;
}
