#include <stdio.h>

long long factorial(int n) {
    if (n == 0 || n == 1)
        return 1;
    else
        return n * factorial(n - 1);
}

int main() {
    int num1, num2;
    long long fact1, fact2;
    printf("Enter first number: ");
    scanf("%d", &num1);

    printf("Enter second number: ");
    scanf("%d", &num2);
    fact1 = factorial(num1);
    fact2 = factorial(num2);
    printf("Factorial of %d = %lld\n", num1, fact1);
    printf("Factorial of %d = %lld\n", num2, fact2);

    return 0;
}


