#include <stdio.h>

// Function to find GCD using recursion
int gcd(int a, int b) {
    if (b == 0)
        return a;
    else
        return gcd(b, a % b);
}

// Function to find LCM using recursion
int lcm(int a, int b) {
    static int multiple = 0;  // Static variable to preserve value between recursive calls
    multiple += b;
    if (multiple % a == 0 && multiple % b == 0)
        return multiple;
    return lcm(a, b);
}

int main() {
    int num1, num2, result;

    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);

    result = lcm(num1, num2);

    printf("LCM of %d and %d is %d\n", num1, num2, result);

    return 0;
}
x
