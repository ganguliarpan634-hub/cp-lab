#include<stdio.h>
int main()
{
int distance,meter,km;
printf("enter distance in meter:");
scanf("&d",distance);
km = meter/1000;
meter=meter%1000;
printf("equivalent distance:%d km,%d meter");
return 0;
}

