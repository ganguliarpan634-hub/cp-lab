#include<stdio.h>
int main()
{
int number ;
int firstdigit,lastdigit;
int sum;
printf("enter a six digit number:");
scanf("%d",&number);
lastdigit = number%10;
firstdigit = number/100000;
sum = firstdigit + lastdigit;
printf("sum of firstdigit and lastdigit is %d",firstdigit + lastdigit);
return 0;
}

