#include<stdio.h>
int main()
{
int number;
int firstdigit,seconddigit,thirddigit;
printf("enter a number:");
scanf("%d",number);
firstdigit=number/100;
seconddigit=(number/100)%10;
thirddigit=number%10;
printf("the sum of firstdigit,seconddigit,thirtdigit is %d",firstdigit +seconddigit+thirddigit);
return 0;
}

