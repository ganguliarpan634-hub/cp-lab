#include<stdio.h>
int main()
{int hours,minutes,seconds,totalseconds;
printf("enter total seconds:");
scanf("%d",totalseconds);
hours =(totalseconds/3600);
minutes=(totalseconds%3600)/60;
seconds=(totalseconds%3600)/60;
printf("equivalent time : %d hours,%d minutes,%d seconds");
return 0;
}

