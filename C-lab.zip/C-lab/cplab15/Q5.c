#include <stdio.h>

int main() {
    char str[100], sub[100];
    int start, len, i;

    printf("Enter a string: ");
    gets(str);

    printf("Enter starting position: ");
    scanf("%d", &start);

    printf("Enter length of substring: ");
    scanf("%d", &len);

    for (i = 0; i < len; i++) {
        sub[i] = str[start - 1 + i];
    }
    sub[i] = '\0';

    printf("Substring = %s\n", sub);

    return 0;
}
