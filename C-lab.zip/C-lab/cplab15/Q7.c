#include <stdio.h>

int main() {
    char str[500];
    int v = 0, c = 0, w = 1, l = 0, ch = 0, i;

    printf("Enter a string: ");
    gets(str);

    for (i = 0; str[i] != '\0'; i++) {
        ch++;

        if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' ||
            str[i] == 'o' || str[i] == 'u' || str[i] == 'A' ||
            str[i] == 'E' || str[i] == 'I' || str[i] == 'O' ||
            str[i] == 'U')
            v++;
        else if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))
            c++;
        else if (str[i] == ' ')
            w++;
        else if (str[i] == '\n')
            l++;
    }

    printf("\nVowels: %d", v);
    printf("\nConsonants: %d", c);
    printf("\nWords: %d", w);
    printf("\nNew lines: %d", l);
    printf("\nTotal characters: %d\n", ch);

    return 0;
}

