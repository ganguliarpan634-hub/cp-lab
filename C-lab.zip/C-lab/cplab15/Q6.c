#include <stdio.h>

int main() {
    char str[200], word[50], largest[50];
    int i = 0, j = 0, max = 0;

    printf("Enter a sentence: ");
    gets(str);

    while (1) {
        if (str[i] != ' ' && str[i] != '\0') {
            word[j++] = str[i];
        } else {
            word[j] = '\0';
            if (j > max) {
                max = j;
                int k;
                for (k = 0; k <= j; k++)
                    largest[k] = word[k];
            }
            j = 0;
        }

        if (str[i] == '\0')
            break;
        i++;
    }

    printf("Largest word: %s\n", largest);
    printf("Length: %d\n", max);

    return 0;
}
