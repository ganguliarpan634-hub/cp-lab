#include <stdio.h>

int main() {
    int n, i, sum = 0;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++) {
        sum += i * i; 
    }

 
    printf("Sum of the series 1^2 + 2^2 + ... + %d^2 = %d\n", n, sum);

    return 0;
}
