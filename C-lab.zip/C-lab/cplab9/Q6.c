#include<stdio.h>
int main(){
int n,i;
int term =1;
printf("enter the number of terms:");
scanf("%d",&n);
printf("pattern:");
for(i=1;i<=n;i++){
printf("%d",term);
term = 2*term +1;
}
return 0;
}
