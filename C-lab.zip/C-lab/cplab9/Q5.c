#include <stdio.h>

int main() {
    int current_term = 1; // Initialize with the first term
    int i;

    // Loop to generate and print the terms
    for (i = 0; i < 5; i++) { // Print 5 terms
        printf("%d", current_term);

        // Add a comma and space if it's not the last term
        if (i < 4) {
            printf(", ");
        }

        // Calculate the next term
        current_term = (current_term * 2) + 1;
    }

    printf("\n"); // Print a newline at the end
    return 0;

