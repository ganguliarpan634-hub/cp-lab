#include<stdio.h>
int main ()
{
int num1,num2;
printf("enter the first number:");
scanf("%d",&num1);
printf("enter the second number");
scanf("%d",&num2);
if(num1==num2){
printf("both are equal");
}
else if(num1>num2){
printf("%d is greater",num1);
}
else
printf("%d is greater",num2);
return 0;
}

