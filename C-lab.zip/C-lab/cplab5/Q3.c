#include<stdio.h>
int main()
int marks;
printf("enter  total marks:");
scanf("%d",&marks);
if(marks>=90);{
printf("your grade is o");
else if (marks>=80 && <=89);
printf("your grade is E");
else if (marks>=70 && <=79);
printf("your grade is A");
else if (marks>=60 && <= 69)
printf("your grade is B");
return 0;
}



