#include<stdio.h>
int main()
{
int weakday;
printf("enter weakday number(0-6): ");
scanf("%d",&weakday);
switch (weakday){
       case 0:{
        printf("sunday\n");}
        break;
       case 1:{
        printf("monday\n");}
        break;
       case 2:{
        printf("tuesday\n");}
        break;
       case 3:{
        printf("wednesday\n");}
        break;
       case 4:{
        printf("thrusday\n");}
        break;
       case 5:{
        printf("friday\n");}
        break;
       case 6:{
        printf("saturday\n");}
        break;
   
 default:
    printf("Invalid number .");
   }

return 0;
}

