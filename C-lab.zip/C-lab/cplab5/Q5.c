#include<stdio.h>
int main()
int ch;
{
printf("enter a ch:");
sacnf("%c");
if (character == "a" || ch == "e"||ch== "i"||ch== "o"||ch== "u"||
    ch== "A"||ch == "E"||ch=="I"||ch== "O"||ch=="U"){
printf("the entered character %c is a vowel",character);
}
else{
printf("the entered %d is a constant",character);
}
return 0;
}


