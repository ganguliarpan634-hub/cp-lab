#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    char *ptr;
    int len;
    printf("Enter a string: ");
    gets(str);
    len = strlen(str);
    ptr = &str[len - 1];
    printf("Reversed string: ");
    while (len > 0) {
        printf("%c", *ptr);
        ptr--;
        len--;
    }

    printf("\n");
    return 0;
}
