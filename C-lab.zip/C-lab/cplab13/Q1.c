z#include <stdio.h>

int main() {
    int num1, num2, product;
    int *ptr1, *ptr2;
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);
    ptr1 = &num1;
    ptr2 = &num2;
    product = (*ptr1) * (*ptr2);
    printf("Product = %d\n", product);

    return 0;
}
