#include <stdio.h>

int main() {
    int a[10][10];
    int i, j, n, sum = 0;


    printf("Enter the order of the square matrix: ");
    scanf("%d", &n);#include <stdio.h>

int main() {
    int a[10][10], b[10][10];
    int r1, c1, r2, c2;
    int i, j, flag = 1;

    // Input order of first matrix
    printf("Enter rows and columns of first matrix: ");
    scanf("%d %d", &r1, &c1);

    // Input order of second matrix
    printf("Enter rows and columns of second matrix: ");
    scanf("%d %d", &r2, &c2);

    // Check if orders are same
    if (r1 != r2 || c1 != c2) {
        printf("Matrices are NOT equal (different orders).\n");
        return 0;
    }

    // Input first matrix
    printf("Enter elements of first matrix:\n");
    for (i = 0; i < r1; i++) {
        for (j = 0; j < c1; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    // Input second matrix
    printf("Enter elements of second matrix:\n");
    for (i = 0; i < r2; i++) {
        for (j = 0; j < c2; j++) {
            scanf("%d", &b[i][j]);
        }
    }

    // Compare both matrices
    for (i = 0; i < r1; i++) {
        for (j = 0; j < c1; j++) {
            if (a[i][j] != b[i][j]) {
                flag = 0;
                break;
            }
        }
    }

    // Display result
    if (flag == 1)
        printf("Matrices are EQUAL.\n");
    else
        printf("Matrices are NOT equal.\n");

    return 0;
}



    printf("Enter the elements of the matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    printf("\nMatrix entered:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%d\t", a[i][j]);
        }
        printf("\n");
    }

    for (i = 0; i < n; i++) {
        for (j = i; j < n; j++) {
            sum += a[i][j];
        }
    }

    printf("\nSum of upper triangular elements = %d\n", sum);

    return 0;
}

