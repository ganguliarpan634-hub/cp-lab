#include <stdio.h>

int main() {
    int temp[2][7];
    int i, j;

    printf("Enter temperatures of 2 cities for 7 days:\n");
    for (i = 0; i < 2; i++) {
        printf("\nCity %d:\n", i + 1);
        for (j = 0; j < 7; j++) {
            printf("Day %d: ", j + 1);
            scanf("%d", &temp[i][j]);
        }
    }

    printf("\nDisplaying temperatures:\n");
    for (i = 0; i < 2; i++) {
        printf("\nCity %d:\n", i + 1);
        for (j = 0; j < 7; j++) {
            printf("Day %d: %d°C\n", j + 1, temp[i][j]);
        }
    }

    return 0;
}
